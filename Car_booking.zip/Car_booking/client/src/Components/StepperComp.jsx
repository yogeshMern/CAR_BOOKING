import React from "react";
import { Stepper, Step, Button } from "@material-tailwind/react";
import { FaUserPlus, FaCar, FaWrench, FaCalendarAlt } from "react-icons/fa";
import { IoMdSend } from "react-icons/io";
const StepperComp = ({ activeStep, setIsFirstStep, setIsLastStep }) => {
  return (
    <div className="mt-6">
      <Stepper
        activeStep={activeStep}
        isLastStep={(value) => setIsLastStep(value)}
        isFirstStep={(value) => setIsFirstStep(value)}
      >
        <Step>
          <FaUserPlus className="h-5 w-5" />
        </Step>
        <Step>
          <FaCar className="h-5 w-5" />
        </Step>
        <Step>
          <FaWrench className="h-5 w-5" />
        </Step>
        <Step>
          <IoMdSend className="h-5 w-5" />
        </Step>
        <Step>
          <FaCalendarAlt className="h-5 w-5" />
        </Step>
      </Stepper>
    </div>
  );
};

export default StepperComp;
