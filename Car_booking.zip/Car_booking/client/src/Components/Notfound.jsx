import React from "react";
import { Link } from "react-router-dom";

const Notfound = () => {
  return (
    <div className="flex flex-grow items-center justify-center">
      <div className="rounded-lg p-8 text-center mt-20">
        <h1 className="mb-4 text-4xl font-bold">404</h1>
        <p className="text-gray-600">Oops! Booking not found.</p>
        <Link
          to="/"
          className="mt-4 inline-block rounded font-bold hover:text-white border border-gray-500 hover:bg-[#6BBB69] text-[12px] px-6 py-2 bg-"
        >
          Go back and create Booking
        </Link>
      </div>
    </div>
  );
};

export default Notfound;
